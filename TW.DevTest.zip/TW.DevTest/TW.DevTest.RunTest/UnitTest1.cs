using NUnit.Framework;

namespace TW.DevTest.RunTest
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {

         
            Assert.Pass();
        }
    }
}